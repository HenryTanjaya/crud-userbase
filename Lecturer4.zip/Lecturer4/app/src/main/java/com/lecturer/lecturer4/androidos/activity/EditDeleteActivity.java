package com.lecturer.lecturer4.androidos.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.lecturer.lecturer4.androidos.R;
import com.lecturer.lecturer4.androidos.aabase.BaseActivity;

public class EditDeleteActivity extends BaseActivity {

    TextView id, appname, applink, applinkname;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_delete);
        init();
    }

    public void init() {
        id = findViewById(R.id.id);
        appname = findViewById(R.id.appname);
        applink = findViewById(R.id.applink);
        applinkname = findViewById(R.id.applinkname);

        Intent i = getIntent();
        if (i != null) {
            id.setText("id = " + i.getStringExtra("id"));
            appname.setText("appname = " + i.getStringExtra("appname"));
            applink.setText("applink = " + i.getStringExtra("applink"));
            applinkname.setText("applinkname = " + i.getStringExtra("applinkname"));
        }
    }
}
