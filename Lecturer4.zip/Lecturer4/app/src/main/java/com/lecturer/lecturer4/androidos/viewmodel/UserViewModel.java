package com.lecturer.lecturer4.androidos.viewmodel;

import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
import android.arch.lifecycle.LiveData;

import com.lecturer.lecturer4.androidos.db.AppDatabase;
import com.lecturer.lecturer4.androidos.helper.AsyncTaskUtils;
import com.lecturer.lecturer4.androidos.listener.OnActionListener;
import com.lecturer.lecturer4.androidos.model.User;

import java.util.List;

/**
 * Created by ASUS on 5/22/2018.
 */

public class UserViewModel extends AndroidViewModel {

    private AppDatabase appDatabase;
    private final LiveData<List<User>> liveLiUser;

    public UserViewModel(Application application) {
        super(application);
        appDatabase = AppDatabase.getDatabase(this.getApplication());
        liveLiUser = appDatabase.userDao().loadLiveUser();
    }

    public LiveData<List<User>> getLiveLiUser() {
        return liveLiUser;
    }

    public void getLiUserViewModel(OnActionListener oal){
        new AsyncTaskUtils(new AsyncTaskUtils.OnStartProcessParam() {
            @Override
            public void onProcess(Object param) {
                oal.onOk(appDatabase.userDao().loadUser());
            }}).execute((Object[]) null);
    }

    public void addUser(User user) {
        new AsyncTaskUtils(new AsyncTaskUtils.OnStartProcessParam() {
            @Override
            public void onProcess(Object param) {
                appDatabase.userDao().insert(user);
            }}).execute((Object[]) null);
    }

//    public void getUser(User user) {
//        new AsyncTaskUtils(new AsyncTaskUtils.OnStartProcessParam() {
//            @Override
//            public void onProcess(Object param) {
//                appDatabase.userDao().oneUser(user.getUser_name());
//            }}).execute((Object[]) null);
//    }
}
