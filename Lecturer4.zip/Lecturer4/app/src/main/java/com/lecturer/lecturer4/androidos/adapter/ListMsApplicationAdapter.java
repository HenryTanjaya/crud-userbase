package com.lecturer.lecturer4.androidos.adapter;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.lecturer.lecturer4.androidos.R;
import com.lecturer.lecturer4.androidos.model.MsApplication;

import java.util.List;

/**
 * Created by IT on 4/16/2018.
 */

public class ListMsApplicationAdapter extends RecyclerView.Adapter<ListMsApplicationAdapter.MsApplicationViewHolder> {

    private List<MsApplication> appList;
    private static ClickListener clickListener;

    @Override
    public MsApplicationViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.li_ms_adapter, parent, false);

        return new MsApplicationViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(MsApplicationViewHolder holder, int position) {
        MsApplication o = appList.get(position);
        holder.appId.setText(o.getId());
        holder.appName.setText(o.getAppName());
        holder.appLinkName.setText(o.getAppLinkName());

        if(position%2==1) {
            holder.itemView.setBackgroundResource(R.drawable.list_item_odd);
        } else {
            holder.itemView.setBackgroundResource(R.drawable.list_item_even);
        }
    }

    @Override
    public int getItemCount() {
        return appList != null ? appList.size() : 0;
    }

    public MsApplication getItem(int position){
        return appList.get(position);
    }

    public void setList(List<MsApplication> appList){
        this.appList = appList;
    }

    public void setOnItemClickListener(ClickListener cl){
        this.clickListener = cl;
    }

    public interface ClickListener {
        void onItemClick(int position, View v);
        void onItemLongClick(int position, View v);
    }

    static class MsApplicationViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener, View.OnLongClickListener {

        TextView appId, appName, appLinkName;

        public MsApplicationViewHolder(View v) {
            super(v);
            v.setOnClickListener(this);
            v.setOnLongClickListener(this);
            appId = v.findViewById(R.id.li_ms_application_id);
            appName = v.findViewById(R.id.li_ms_application_app_name);
            appLinkName = v.findViewById(R.id.li_ms_application_app_link_name);
        }

        @Override
        public void onClick(View v) {
            clickListener.onItemClick(getAdapterPosition(), v);
        }

        @Override
        public boolean onLongClick(View v) {
            clickListener.onItemLongClick(getAdapterPosition(), v);
            return true;
        }
    }
}