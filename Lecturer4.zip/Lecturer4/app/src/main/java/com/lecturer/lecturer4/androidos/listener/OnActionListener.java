package com.lecturer.lecturer4.androidos.listener;

import com.lecturer.lecturer4.androidos.model.MsApplication;
import com.lecturer.lecturer4.androidos.model.User;

import java.util.List;

/**
 * Created by IT on 1/24/2018.
 */

public interface OnActionListener {
    public void onOk(List<User> list);
}
