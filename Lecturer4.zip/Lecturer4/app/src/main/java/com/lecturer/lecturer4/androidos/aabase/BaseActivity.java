package com.lecturer.lecturer4.androidos.aabase;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by IT on 1/23/2018.
 */

public class BaseActivity extends AppCompatActivity {

    public Context getCtx(){
        return this;
    }

}
